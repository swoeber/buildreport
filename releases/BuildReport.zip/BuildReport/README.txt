Instructions:
1. Open the settings.xml and edit the fields and add fields if needed. Use the same ranges you used in the notes on the excel. You will need to go in and update the header  sections.
2. Add file to folder you want to parse.
3. Rename the file you want parsed to "parseme.txt"
4. Then run BuildReport.exe
5. Win!

fieldType in XML
Leave this blank if not a date field. Date fields can concist of fields that are either 201804 OR 20180401. If any other format let me know and I can add them.


If any issues contact me.